# LK Robotics UI documentation

| Field | Value |
| --- | --- |
| Type | Documentation index |
| Status | Current |
| Owner | Robotics domain engineering |
| Last reviewed | 2026-08-09 |

`docs/`의 탐색 진입점이다. 공통 LDS 규약과 source-of-truth는 peer 패키지
`@lk-design-system/lds-core`의 `docs/`가 소유한다. 로보틱스는 채택 계약 입력 다섯
개만 해시로 고정해 [`package/upstream-snapshot.json`](package/upstream-snapshot.json)에 기록한다.
여기서는 로보틱스 소관 문서만 나열한다.

## 작업 시작 경로

- 제품 UI 신규 구현·LDS 전환: [`ROBOTICS_UI_ADOPTION.md`](ROBOTICS_UI_ADOPTION.md)와 생성된 [`package/adoption-workflow.md`](package/adoption-workflow.md)
- 기계 판독 계약: [`package/adoption-checklist.json`](package/adoption-checklist.json), [`package/manifest.json`](package/manifest.json), [`package/llms.txt`](package/llms.txt)
- 좌표·지도·내비게이션 통합: 아래 Current 계약 중 해당 문서

컴포넌트 교체만으로 LDS 전환은 완료되지 않는다.

## 규약과 계약 (Current)

| Document | Role |
| --- | --- |
| [`NAVIGATION_EXPRESSION_CONVENTIONS.md`](NAVIGATION_EXPRESSION_CONVENTIONS.md) | Navigation 오버레이가 지도 위에서 의미를 그리는 규약 — 업스트림 동명 문서가 공유 정책의 authoritative이고, 이 문서는 consumer 특화. 값의 단일 소스는 `_navigationVocabulary` |
| [`NAVIGATION_COORDINATE_CONTRACT.md`](NAVIGATION_COORDINATE_CONTRACT.md) | frame·timestamp·projection 증명 계약 — ROS 지도/경로/포즈 통합 전 필독. `check:coordinates`가 검증 |
| [`OCCUPANCY_MAP_CONVENTIONS.md`](OCCUPANCY_MAP_CONVENTIONS.md) | 구조 베이스맵의 free/occupied/unknown 시각 규약 — 지도는 무채색, accent는 내비게이션 콘텐츠 전용 |
| [`OVERLAY_STATUS_CHIP.md`](OVERLAY_STATUS_CHIP.md) | 표면 위 비차단 상태 칩 — 레이아웃·포인터 불참, inert 밖, 하우스 톤 글리프 미러링. 코어 편입 제안 진행 중 |

## 감사와 평가 (Audit)

| Document | Role |
| --- | --- |
| [`SELECTION_FOCUS_AUDIT.md`](SELECTION_FOCUS_AUDIT.md) | 선택(정적 기하) vs 키보드 포커스(포커스 색)의 소유 경계 원장 — 값의 소스는 `NAV_SELECTION`/`NAV_FOCUS` |
| [`STRUCTURE_ASSESSMENT.md`](STRUCTURE_ASSESSMENT.md) | LDS 전반 구조 건강도 스냅숏 — 부채 목록(이중 모듈 그래프, 업스트림 조율)과 갱신 규칙 |
| [`ROBOT_POSE_TONE_AUDIT.md`](ROBOT_POSE_TONE_AUDIT.md) | RobotPose `offline`/`idle`이 뷰어 안에서 같은 본체 색으로 해석되는 문제 — 소비자 실측 근거와 선택지 (Open) |

## 계획 (Plan)

| Document | Status |
| --- | --- |
| [`FLEET_UI_REFERENCE_PLAN.md`](FLEET_UI_REFERENCE_PLAN.md) | Phase 0–2 첫 증분 구현됨; 이후 단계 미착수 |

## 근거 자료

- [`references/ATTRIBUTIONS.md`](references/ATTRIBUTIONS.md): 외부 자료 출처

## 계약의 소재

디자인 계약의 1차 소스는 문서가 아니라 실행 코드다: 스토리 play 단언(개수는 `check:story-play` 출력이 정본),
`_navigationVocabulary`·`_viewerOverlay` 상수 모듈, conformance 검사. 문서
산문과 코드가 충돌하면 코드·play가 우선하고, 문서를 갱신한다.
